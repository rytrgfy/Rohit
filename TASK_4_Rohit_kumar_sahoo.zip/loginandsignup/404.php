<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>error page</title>
</head>
<body>
    <h1>404 erro page not found</h1>
    <p>Go back:➡️ <a href='dashboard.php'>Click me</a></p>
</body>
</html>